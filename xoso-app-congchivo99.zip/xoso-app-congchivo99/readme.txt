﻿Để ứng dụng hoạt động được bên máy của anh/chị. Anh.chị thay thế nội dung của chuỗi connectionStrings có name="xosoConn" trong File xoso.exe.config tương ứng với SQL Server của bên anh/chị

Source=<SQL Server name>;
Catalog=<Tên database>;
Trên máy của mình dùng Windows Authentication. Nếu anh/chị dùng SQL Server Authentication, xin thêm đoạn ;User ID=<tên user>;Password=<password>

Ứng dụng viết trên Visual Studio 2015 và MS SQL Server 2008.
(Anh/chị vui lòng tìm file backup xoso.bak của databse và restore vào SQL Server của bên anh/chị.)

---
Võ Chí Công
congchivo99@gmail.com